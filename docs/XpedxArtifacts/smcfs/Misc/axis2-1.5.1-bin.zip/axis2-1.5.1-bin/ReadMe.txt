1)Modify  axis2-1.5.1\bin\axis2server.bat file 
Change AXIS2_HOME
e.g. AXIS2_HOME=D:\xpedx\axis2-1.5.1-bin\axis2-1.5.1
2)Check whether JAVA_HOME is set properly.
3)Start the server by clicking axis2-1.5.1\bin\axis2server.bat
4)Check whether services are up on clicking below URL
http://localhost:8080/axis2/services/
 
5)You can Deploy .aar filr in the directory axis2-1.5.1\repository\services.
6)Modify the output xml axis2-1.5.1\PriceAndAvailibiltyOutput.xml for desired output