Sample for Yahoo - Search - JSON
=================================

Introduction
============

Axis2 client API has facilities to accept responses in JSON.

Yahoo provides an API to call its search service and retrieve JSON responses. This sample demonstrates how to call Yahoo
search service using an Axis2 client which accepts a JSON response.

Pre-Requisites
==============

Apache Ant 1.6.2 or later

Running The Sample
==================

Type "ant" from Axis2_HOME/samples/yahoojsonsearch directory.

Help
====
Please contact axis-user list (axis-user@ws.apache.org) if you have any trouble running the sample.
